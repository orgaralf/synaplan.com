<?php


namespace Codewithkyrian/TestPackage;


class TestPackage 
{
    public function execute() : void 
    {
	echo "Test package executed";
    }
}
